class Equipamento { 
  var nomeEquipamento;
  String local;
  dynamic codPatrimonio;

  
  Equipamento(this.nomeEquipamento, this.local, this.codPatrimonio);

}

void main (){
  
  Equipamento e1 = new Equipamento("Impressora 3D", "Lab de Protótipos", 12345);
  
  e1.codPatrimonio = "12345-A";
  
  print("Equipamento: ${e1.nomeEquipamento}. Local fixo: ${e1.local}. Código do equipamento: ${e1.codPatrimonio}");
  
  verificarTipo(e1.nomeEquipamento);
  verificarTipo(e1.local);
  verificarTipo(e1.codPatrimonio);
  
  //É possível mudar o tipo de codPatrimonio pois variáveis do tipo dynamic podem receber qualquer tipo de valor a qualquer momento do código. Mesmo que tenha sido instanciada como int, mais a frente no código ela pode ser alterada para um tipo String ou qualquer outro.
  //Não é possível mudar o tipo de local pois já está sendo atribuído isso na declaração: STRING local. String não é um tipo de variável que aceita essa mudança como dynamic.
}


 void verificarTipo(dynamic nulo) {  
  if (nulo is int) {  
    print("$nulo é int");  
  } else if (nulo is double) {  
    print("$nulo é double");  
  } else if (nulo is bool) {  
    print("$nulo é bool");  
  } else if (nulo is String) {  
    print("$nulo é String");  
  } else {
    print("Erro.");
  }
}