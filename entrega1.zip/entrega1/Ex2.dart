class Funcionario {
  String nome;
  String? cargo;

  Funcionario(this.nome, this.cargo);
  
  void imprimirFuncionario(){
    if(cargo != null){
      print("Nome: $nome\nCargo: $cargo");
    }else{
      print("Nome: $nome.");
    }
  }
}

void main(){
    Funcionario f1 = new Funcionario("Ana", "Analista");
  Funcionario f2 = new Funcionario("Carlos", null);
  
  f1.imprimirFuncionario();
  f2.imprimirFuncionario();
}