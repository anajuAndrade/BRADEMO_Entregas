class Laptop {
  int id;
  String nome;
  int ram;
  double clockCpu; 

  Laptop(this.id, this.nome, this.ram, this.clockCpu); 
  
  void imprimirLaptop(){
    print("Modelo: $nome\nRam: $ram\nCLock da CPU: $clockCpu");      
  }
  
}

void main(){
 Laptop l1 = Laptop(1, "Samsung Book 2", 8, 2.4);
  Laptop l2 = Laptop(2, "Dell XPS", 16, 4.2);
  Laptop l3 = Laptop(3, "Mac book Air", 8, 3.5);

  l1.imprimirLaptop();
  l2.imprimirLaptop();
  l3.imprimirLaptop();
}