class Laptop {
  int id;
  String nome;
  int ram;
  double clockCpu; 

  Laptop(this.id, this.nome, this.ram, this.clockCpu); 
  
  void imprimirLaptop(){
    print("Modelo: $nome\nRam: $ram\nCLock da CPU: $clockCpu");
   }
  
  Laptop.navegacaoInternet(this.id, this.nome)
    : ram = 4,
      clockCpu = 1.8;
  
  Laptop.escritorio(this.id, this.nome)
      : ram = 8,
        clockCpu = 2.5;
  
    Laptop.programacao(this.id, this.nome)
      : ram = 16,
        clockCpu = 3.8;
  
}

void main(){
 Laptop l1 = Laptop(1, "Samsung Book 2", 8, 2.4);
  Laptop l2 = Laptop(2, "Dell XPS", 16, 4.2);
  Laptop l3 = Laptop(3, "Mac book Air", 8, 3.5);
  
  Laptop l4 = Laptop.navegacaoInternet(4, "Multilaser Ultra");
  Laptop l5 = Laptop.escritorio(5, "Mac book Pro");
  Laptop l6 = Laptop.programacao(6, "Acer Nitro 5");

  l1.imprimirLaptop();
  l2.imprimirLaptop();
  l3.imprimirLaptop();
  l4.imprimirLaptop();
  l5.imprimirLaptop();
  l6.imprimirLaptop();
}