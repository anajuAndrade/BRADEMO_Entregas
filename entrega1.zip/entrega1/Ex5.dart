import 'dart:io';

class House {
  int id;
  String name;
  double price;
  
  House(this.id, this.name, this.price);
}

void main() {

  List<House> casas = [];

  
  for (int i = 1; i <= 3; i++) {
    print("Cadastro da casa $i");
    print("Digite o ID: ");
    int id = int.parse(stdin.readLineSync()!);
    print("Digite o nome: ");
    String nome = stdin.readLineSync()!;
    print ("Digite o preço: ");
    double preco = double.parse(stdin.readLineSync()!);
    casas.add(House(id, nome, preco));

  }
  
  for (var casa in casas) {
    casa..name = "${casa.name} (Cadastrada)";
  }

  print("\nCasas cadastradas:\n");
  for (var casa in casas) {
    print("ID: ${casa.id}");
    print("Nome: ${casa.name}");
    print("Preço: R\$ ${casa.price}");
  }
}