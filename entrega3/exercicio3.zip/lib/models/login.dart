class Login {
  final String usuario;
  final String senha;

  Login({required this.usuario, required this.senha});
}